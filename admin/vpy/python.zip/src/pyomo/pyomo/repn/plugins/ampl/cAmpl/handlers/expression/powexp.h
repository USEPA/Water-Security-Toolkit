#include <Python.h>
#include "../../util.h"
#include "../../cAmpl.h"

int _handle_powexp(PyObject * context, PyObject * exp, PyObject ** ampl_repn);
