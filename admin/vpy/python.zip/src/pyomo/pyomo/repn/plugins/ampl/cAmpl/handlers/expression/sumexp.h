#include <Python.h>
#include "../../util.h"

int _handle_sumexp(PyObject * context, PyObject * exp, PyObject ** ampl_repn);
