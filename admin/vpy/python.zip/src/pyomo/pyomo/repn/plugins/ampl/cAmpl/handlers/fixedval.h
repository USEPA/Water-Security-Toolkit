#include <Python.h>
#include "../util.h"

int _handle_fixedval(PyObject * context, PyObject * exp, PyObject ** ampl_repn);
