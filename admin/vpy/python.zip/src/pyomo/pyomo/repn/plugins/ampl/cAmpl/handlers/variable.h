#include <Python.h>
#include "../util.h"

int _handle_variable(PyObject * context, PyObject * exp, PyObject ** ampl_repn);
