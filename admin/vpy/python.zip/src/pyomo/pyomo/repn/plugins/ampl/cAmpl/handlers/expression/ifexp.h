#include <Python.h>
#include "../../util.h"

int _handle_ifexp(PyObject * context, PyObject * exp, PyObject ** ampl_repn);
