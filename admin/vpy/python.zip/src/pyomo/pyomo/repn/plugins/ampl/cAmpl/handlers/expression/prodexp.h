#include <Python.h>
#include "../../util.h"

int _handle_prodexp(PyObject * context, PyObject * exp, PyObject ** ampl_repn);
