#
# TEVA-SPOT Toolkit Installation generated with pywst_install.
#
# This directory is managed with virtualenv, which creates a
# virtual Python installation.  If the 'bin' directory is put in
# user\'s PATH environment, then the bin/python command can be used to
# employ the TEVA-SPOT Toolkit.
#
# Directories:
#   admin      Administrative data for maintaining this distribution
#   bin        Scripts and executables
#   data       Test data
#   dist       Python packages that are not intended for development
#   doc        Documentation and tutorials
#   examples   Examples
#   include    Python header files
#   lib        Python libraries and installed packages
#   src        Python packages whose source files can be
#              modified and used directly within this virtual Python
#              installation.
#   Scripts    Python bin directory (used on MS Windows)
#   test       Test directory
#   util       Utility scripts
#
